import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const normalizeRole = (role: unknown) => String(role || "employee").trim() === "admin" ? "admin" : "employee";
const normalizeBool = (value: unknown, fallback = true) => value === undefined ? fallback : value !== false && value !== "false";
const normalizePermissions = (value: unknown) => value && typeof value === "object" && !Array.isArray(value) ? value : {};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || Deno.env.get("PROJECT_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("ANON_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SERVICE_ROLE_KEY");

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      console.error("Missing env vars", { hasUrl: !!supabaseUrl, hasAnon: !!anonKey, hasService: !!serviceRoleKey });
      return json({ error: "Missing Supabase environment variables" }, 500);
    }

    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const adminClient = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { data: authData, error: authError } = await userClient.auth.getUser();
    if (authError || !authData?.user) {
      console.error("Unauthorized", authError);
      return json({ error: "Unauthorized" }, 401);
    }

    const caller = authData.user;
    const { data: callerProfile, error: profileError } = await adminClient
      .from("app_user_profiles")
      .select("id, user_id, role, is_active, email")
      .or(`user_id.eq.${caller.id},email.eq.${caller.email}`)
      .maybeSingle();

    if (profileError) {
      console.error("Profile lookup error", profileError);
      return json({ error: profileError.message }, 500);
    }
    if (!callerProfile || callerProfile.role !== "admin" || callerProfile.is_active !== true) {
      console.error("Caller is not active admin", { caller: caller.email, callerProfile });
      return json({ error: "Only active admin users can manage accounts" }, 403);
    }

    const body = await req.json().catch(() => ({}));
    const action = String(body.action || "create-user").trim();

    if (action === "list-users") {
      const { data, error } = await adminClient
        .from("app_user_profiles")
        .select("id,user_id,full_name,email,role,is_active,employee_id,permissions,created_at,updated_at")
        .order("created_at", { ascending: false });
      if (error) {
        console.error("List users error", error);
        return json({ error: error.message }, 500);
      }
      return json({ ok: true, users: data || [] });
    }

    if (action === "update-user") {
      const id = String(body.id || "").trim();
      if (!id) return json({ error: "Missing user profile id" }, 400);
      if (id === callerProfile.id && normalizeBool(body.isActive, true) === false) {
        return json({ error: "Cannot disable current admin account" }, 400);
      }
      const email = String(body.email || "").trim().toLowerCase();
      const fullName = String(body.fullName || body.full_name || "").trim();
      if (!email || !email.includes("@")) return json({ error: "Invalid email" }, 400);
      if (!fullName) return json({ error: "Full name is required" }, 400);
      const payload = {
        full_name: fullName,
        email,
        role: normalizeRole(body.role),
        is_active: normalizeBool(body.isActive ?? body.is_active, true),
        employee_id: String(body.employeeId || body.employee_id || "").trim() || null,
        permissions: normalizePermissions(body.permissions),
        updated_at: new Date().toISOString(),
      };
      const { data, error } = await adminClient
        .from("app_user_profiles")
        .update(payload)
        .eq("id", id)
        .select("id,user_id,full_name,email,role,is_active,employee_id,permissions,created_at,updated_at")
        .single();
      if (error) {
        console.error("Update profile error", error);
        return json({ error: error.message }, 500);
      }
      if (data?.user_id) {
        const { error: authUpdateError } = await adminClient.auth.admin.updateUserById(data.user_id, {
          email,
          user_metadata: { full_name: fullName },
          ban_duration: payload.is_active ? "none" : "876000h",
        });
        if (authUpdateError) console.warn("Auth update warning", authUpdateError);
      }
      return json({ ok: true, user: data });
    }

    if (action === "toggle-user") {
      const id = String(body.id || "").trim();
      if (!id) return json({ error: "Missing user profile id" }, 400);
      const isActive = normalizeBool(body.isActive, true);
      if (id === callerProfile.id && !isActive) return json({ error: "Cannot disable current admin account" }, 400);
      const { data: profile, error: findError } = await adminClient
        .from("app_user_profiles")
        .select("id,user_id,is_active")
        .eq("id", id)
        .single();
      if (findError) return json({ error: findError.message }, 500);
      const { data, error } = await adminClient
        .from("app_user_profiles")
        .update({ is_active: isActive, updated_at: new Date().toISOString() })
        .eq("id", id)
        .select("id,user_id,full_name,email,role,is_active,employee_id,permissions,created_at,updated_at")
        .single();
      if (error) return json({ error: error.message }, 500);
      if (profile?.user_id) {
        const { error: authToggleError } = await adminClient.auth.admin.updateUserById(profile.user_id, {
          ban_duration: isActive ? "none" : "876000h",
        });
        if (authToggleError) console.warn("Auth toggle warning", authToggleError);
      }
      return json({ ok: true, user: data });
    }

    if (action === "delete-user") {
      const id = String(body.id || "").trim();
      if (!id) return json({ error: "Missing user profile id" }, 400);
      if (id === callerProfile.id) return json({ error: "Cannot delete current admin account" }, 400);
      const { data: profile, error: findError } = await adminClient
        .from("app_user_profiles")
        .select("id,user_id,email")
        .eq("id", id)
        .single();
      if (findError) return json({ error: findError.message }, 500);
      if (profile?.user_id) {
        const { error: authDeleteError } = await adminClient.auth.admin.deleteUser(profile.user_id);
        if (authDeleteError) console.warn("Auth delete warning", authDeleteError);
      }
      const { error } = await adminClient.from("app_user_profiles").delete().eq("id", id);
      if (error) return json({ error: error.message }, 500);
      return json({ ok: true, deleted: true, id });
    }

    // Default action: create-user.
    if (action !== "create-user" && action !== "create") return json({ error: "Unknown action" }, 400);

    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    const fullName = String(body.fullName || body.full_name || "").trim();
    const role = normalizeRole(body.role);
    const isActive = normalizeBool(body.isActive ?? body.is_active, true);
    const employeeId = String(body.employeeId || body.employee_id || "").trim() || null;
    const permissions = normalizePermissions(body.permissions);

    if (!email || !email.includes("@")) return json({ error: "Invalid email" }, 400);
    if (!password || password.length < 6) return json({ error: "Password must be at least 6 characters" }, 400);
    if (!fullName) return json({ error: "Full name is required" }, 400);

    const { data: existingProfile } = await adminClient
      .from("app_user_profiles")
      .select("id,user_id,email")
      .eq("email", email)
      .maybeSingle();
    if (existingProfile?.user_id) return json({ error: "This email already exists" }, 400);

    const { data: newUser, error: createError } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName },
      ban_duration: isActive ? "none" : "876000h",
    });

    if (createError || !newUser?.user) {
      console.error("Create user error", createError);
      return json({ error: createError?.message || "Unable to create user" }, 400);
    }

    const { error: upsertError } = await adminClient
      .from("app_user_profiles")
      .upsert(
        {
          user_id: newUser.user.id,
          full_name: fullName,
          email,
          role,
          is_active: isActive,
          employee_id: employeeId,
          permissions,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "email" }
      );

    if (upsertError) {
      console.error("Profile upsert error", upsertError);
      try { await adminClient.auth.admin.deleteUser(newUser.user.id); } catch (_) {}
      return json({ error: upsertError.message }, 500);
    }

    return json({ ok: true, user_id: newUser.user.id, email, role, is_active: isActive });
  } catch (error) {
    console.error(error);
    return json({ error: error?.message || "Unexpected error" }, 500);
  }
});
